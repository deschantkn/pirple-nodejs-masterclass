/**
 * Entry point for Pizza API
 *
 */

// Dependencies
const Server = require('./lib/server');

// Initialise http server
Server.init();

